<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div style="margin-left: 146px; margin-top: 20px;"> <img src="slideimagefrontpage\knit02.jpg" style="width:1029px;height: 200px"></div>

 <div style="margin-left: 210px; margin-top: 10px;text-align: justify;width: 900px; font-size: 20px;">

<p><b>The KNIT ALUMNI ASSOCIATION </b> provides a platform to its former  students to maintain connections with their Alma Mater and also amongst  themselves and their junior fellows. All the former students of the Institute  and faculty are eligible for the life membership of association. The batch wise  alumni meet is held regularly to provide opportunity to its former students to  meet their batch mates and also to interact with the existing students and  faculty. The alumni of the Institute have been deeply involved in the placement  and other activities for the benefit of the students. The life membership fee  of alumni association is Rs. 200.00.<br><br>
  <b>Some members of this vast family include: -</b></p></div><div  style="margin-left: 210px; margin-top: 0px;text-align: justify;width: 900px; font-size: 20px; box-shadow: 3px 3px 3px 3px gray;height: auto;">
<ul class="UL1">
  <li>Mr. Muesh Goswami, Director,  Product Development at SCA Technologies and also the owner of Swift InfoTech</li>
  <li>Mr. Manish Gupta, Director,  Product Marketing Broadband Products at UTStarcom Inc Greater New York.</li>
  <li>Mr. Satyendra Singh, Head, India  Manufacturing Operations, The Director at Nokia Stamens Networks India.</li>
  <li>Mr. Prashant Bisht,  Vice-president, Morgan Stanley, India</li>
  <li>Mr. Ashish Khurana, Director at  Oracle Corp, San Francisco</li>
  <li>Mr. Vipin Malik, The CEO at  Houston Radar LLC.</li>
  <li>Mr. Sanjay Kr. Saini, Deputy  Director at Defence R&amp;D, Ministry of Defence.</li>
  <li>Mr. Abhay Jain, Deputy General  Manager at Forbes &amp; Company Ltd. Mumbai</li>
  <li>Mr. Amit Goel, Co-Founder &amp;  CEO at Knowledgefaber, Bangalore</li>
  <li>Mr. Rajeev Pathak, General  Manager –ISV Industry</li>
  <li>Mr. Jai Singh, Analyst  /Architect at Ohio Dept of Education</li>
  <li>Mr. Amalendu Gupta, Principal  Consultant at Mindtree Consulting Ltd.</li>
  <li>Mr. Amal Gupta, Senor Consultant  at CGI, Advisor /Mentor to Knowledgefaber</li>
  <li>Mr. Viresh Gupta, Manager ILD  Voice Planning at Bharti Airtel Limited Delhi</li>
  <li>Dr. Vipul Jain, Senior  Consultant at CGL, Advisor/ Mentor to Knowledgefaber</li>
  <li>Mr. Viresh Gupta, Manager ILD  Voice Planning at Bharti Airtel Limited Delhi</li>
  <li>Dr. Vikas Amitabh, Senior  Specialist Engineer at Qatar Petroleum</li>
  <li>Mr. Tushar Gupta, Applications  Sales Executive Consumer &amp; Retail at HP Enterprise Service, US Sales Leader,  Retail and CPG Industries at Mphasis</li>
  <li>Mr. Abhishek Chaurasia, Senior  Systems Analyst at Fiserv India.</li>
  <li>Mr. Anil Kumar, Programme  Manager at Virtusoa Senior Consultant at UBS</li>
  <li>Mr. Vivek Dubey, Manager IBM  Global Services</li>
  <li>Mr. Muesh Goswami, Director, Product  Development at SCA Technologies and also the owner of Swift InfoTech</li>
  <li>Mr. Manish Gupta, Director,  Product Marketing Broadband Products at UTStarcom Inc Greater New York.</li>
  <li>Mr. Satyendra Singh, Head, India  Manufacturing Operations, The Director at Nokia Stamens Networks India</li>
  <li>Mr. Prashant Bisht,  Vice-president, Morgan Stanley, India</li>
  <li>Mr. Ashish Khurana, Director at  Oracle Corp, San Francisco</li>
  <li>Mr. Vipin Malik, The CEO at  Houston Radar LLC.</li>
  <li>Mr. Sanjay Kr. Saini, Deputy  Director at Defence R&amp;D, Ministry of Defence.</li>
  <li>Mr. Abhay Jain, Deputy General  Manager at Forbes &amp; Company Ltd. Mumbai</li>
  <li>Mr. Amit Goel, Co-Founder &amp;  CEO at Knowledgefaber, Bangalore</li>
  <li>Mr. Rajeev Pathak, General  Manager –ISV Industry</li>
  <li>Mr. Jai Singh, Analyst  /Architect at Ohio Dept of Education</li>
  <li>Mr. Amalendu Gupta, Principal  Consultant at Mindtree Consulting Ltd.</li>
  <li>Mr. Amal Gupta, Senor Consultant  at CGI, Advisor /Mentor to Knowledgefaber</li>
  <li>Mr. Viresh Gupta, Manager ILD  Voice Planning at Bharti Airtel Limited Delhi</li>
  <li>Dr. Vipul Jain, Senior  Consultant at CGL, Advisor/ Mentor to Knowledgefaber</li>
  <li>Mr. Viresh Gupta, Manager ILD  Voice Planning at Bharti Airtel Limited Delhi</li>
  <li>Dr. Vikas Amitabh, Senior  Specialist Engineer at Qatar Petroleum</li>
  <li>Mr. Tushar Gupta, Applications  Sales Executive Consumer &amp; Retail at HP Enterprise    Service,US Sales Leader, Retail and CPG  Industries at Mphasis</li>
  <li>Mr. Abhishek Chaurasia, Senior  Systems Analyst at Fiserv India.</li>
  <li>Mr. Anil Kumar, Programme  Manager at Virtusoa Senior Consultant at UBS</li>
  <li>Mr. Vivek Dubey, Manager IBM  Global Services</li>
  <li>Mr. R.P. Shukla AGm at Genius  Power Infrastructure Ltd</li>
  <li>Dr. Sri Niwas Singh Professor  IIT Kanpur Electrical Engg. Deptt</li>
  <li>Mr. Avnish Gupta System  Architect at Pegasystems Inc. Rhode Island Area, Vice President at State Street  Bank</li>
  <li>Mr. Adesh Kumar Singh Senior  Interaction Designer at Yahoo!</li>
  <li>Mr. Vaibhav Kuchhal Assitant  Vice President at Services Mumbai</li>
  <li>Mr. Pranjal Mishra Vice  President (Sales) at Nomutra eReads Technology Ltd</li>
  <li>Mr. Lovekesh Chandra Business  Unit Manager and Global Head Sap&nbsp;CEO at Tech Mahindra, Delhi</li>
  <li>Mr. Rajiv Pant Senior manager at  KPMG Advisory, Saudi Arabia&nbsp;</li>
  <li>Mr. Rakesh Koul GFX SW Apps  Engineering manager, Intel Corp Portland</li>
  <li>Ms. Alpana Dubey Researcher at  Siemens Corporate Technology, India&nbsp;</li>
  <li>Mr. Nitin Srivastava Manager at  Doolittle Consulting LLp</li>
  <li>Mr. Gaurav Mittal Head India  Operation at ITCONS e-Solution Pvt. Ltd</li>
  <li>Dr. Sanjay Jasola Professor and  Dean of School of ICT, Dean Academics at Gautam Buddha University.</li>
  <li>Mr. Vivek Yadav IAS AIR 28,  Assistant Collector Andhra Pradesh</li>
  <li>Mr. Raza Abbas, Senior Program  Manager Manager, CSC India</li>
  <li>Mr. Asheesh Jain Lead Technical  Project Manager at Steria (India) Ltd.</li>
  <li>Mr. Prashant Rohatgi, Principal  Consultant at Infosys Technologies Ltd</li>
  <li>Mr. Ram Pratap Singh, Microsoft</li>
</ul>

<!--<div id="faculty_block1">
<div class="faculty_profilebx">
			
			<div class="ftxt_box"><strong>Mr. Mukesh Goswami </strong> <br/>
			  Director, Product Development<br/> 
			  at SCA Technologies and also the owner of Swift InfoTech.
<br>
</div>
</div>

<div class="faculty_profilebx">
<div class="ftxt_box"><span class="bld"><strong>Mr. Manish Gupta 
 </strong></span><br>
Director, Product Marketing Broadband Products 
at UTStarcom Inc Greater New York.</div>
</div>
<div class="faculty_profilebx">
<div class="ftxt_box"><span class="bld"><strong>Mr. Satendra Singh
 </strong></span> Head, India Manufacturing Operations, <br/>The Director at Nokia Siemens Networks India</div>
</div>

</div>-->


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p><br/><br/><br/><br/>
		</div>
		<!-- InstanceEndEditable --></div>
</div>
<div>
</body>
</html>
<?php include 'footer.php'; ?>
