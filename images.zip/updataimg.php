<!doctype html>
<html>
<head>
	<style>
img {
  border-radius: 0%;
  margin-top: 50px;
  margin-left: 10px;

}



.column {
 float: left;
  width: 218px;
  margin-top: 60px;
margin-left: 170px;
height: 393px;
box-shadow: 3px  3px  3px 3px #888888;

background-color: white;


border: none;


}
.row::after {
  content: "";
  clear: both;
  display: table;
}
.imge
{

}
.post
{text-align:center;
	margin-top:20px;
	height: 20px;
	width: 187px; 
	
	
}
.branch
{text-align:center;
	margin-top:10px;
	height: 20px;
	width: 187px;
	padding-left: 10px; 
	
	
}
.id1
{
	
	margin-top: -33px;
	margin-left: 5px;


}
.rowname
{
	height: 20px;
	width: 187;
text-align: center;
	margin-top:  10px;
  src: url(sansation_light.woff); 
  font-family: Arial, Helvetica, sans-serif;
}

* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  height: 186px;
  position: ;
  
  margin-right: 150px;
	margin-left: 150px;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 0%;
  display: none;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .0} 
  to {opacity: 0.0}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 0px}
}
</style>


	<link rel="stylesheet" type="text/css" href="index.css"> 
</head>
<body>
	<header><div>

<div class="logo"> 
	<div class="leftfloat">
		<div class="cse" text="white"><font class="font1" color="white">COMPUTER SCIENCE & ENGINEERING </font><br> <font class="h4" color="white">KNIT SULTANPUR</font></div>
		<div class="vl"></div>
	<div   class="leftfloat1"></div>
</div><hr>


	

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
	margin-top: 14px;
  overflow: hidden;
  background-color: rgb(0,112,223); 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: rgb(0,112,180);
}

.subnav-content {
  display: none;
  position: absolute;
  
  right: 18px;
  background-color: rgb(0,112,180);
  width: 1029px;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color:rgb(0,112,223);
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}




.subnav-content-1 {
  display: none;
  position: absolute;
  
  right: 30px;
  background-color: rgb(0,112,180);
  width: 1029px;
  z-index: 2;
}

.subnav-content-1 a {
  float: left;
  color: white;
 
  text-decoration: none;
}

.subnav-content-1 a:hover {
  background-color:rgb(0,112,223);
  color: red;
   right:100px;
   
}

.subnav-content:hover .subnav-content-1 {
  display: block;
}

.faculty
{
	height: 50px;
	width: 1029px;
	margin-left: 150px;
	background-color: blue;
	margin-top: 50px;
	text-align: center;
	font-size: 40px;
}



</style>
</head>
<body>

<div class="navbar">
  <a href="#home">Home</a>
  <div class="subnav">
    <button class="subnavbtn">About <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#company">Company</a>
      <a href="#team">Team</a>
      <a href="#careers">Careers</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Services <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#bring">Bring</a>
      <a href="#deliver">Deliver</a>
      <a href="#package">Package</a>
      <a href="#express">Express</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Partners <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#link1">link1</a>
      
      <a href="#link2"></a>
      <a href="#link3">Link 3</a>
      <a href="#link4">Link 4</a>
    </div>
  </div>
  <a href="#contact">Contact</a>
  <div class="subnav">
    <button class="subnavbtn">About <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#company">Company</a> 
      <a href="#team">Team</a>
      <a href="#careers">Careers</a>
    </div>
  </div>
</div>

<div style="padding:0 16px">
 </div>



</div></header>


<div class="faculty"> FACULTY</div>





<?php
   
    include("config.php");
 
        
   



$sql = "SELECT * FROM images";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    // output data of each row 
    while($row = $result->fetch_assoc()) {  ?>
    	<form action="" method="get" enctype="multipart/">

<a href=" faculty.php?id=<?php  echo $row["Email"]; ?>"><div class="column">
	

    	<tr>
    		

<div class="id1"> <img src="<?php  echo $row["image"]; ?>" height="250px" width="187px" > </div>

<div class="rowname"><b>  <?php  echo ucfirst($row["username"]); ?></b></div>
<div class="post">  <b><?php  echo ucfirst($row["post"]); ?></b></div>
<div class="branch">  <b><?php  echo  ucfirst($row["branch"]); ?></b></div>

</div>
    	</tr>

    
</div></a>
</form>
       
<?php
     



      }
} else {
    echo "0 results";
}
 
    ?>

</html>
