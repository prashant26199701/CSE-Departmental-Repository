<!DOCTYPE html>
<html>
<head>
	<title></title><link rel="stylesheet" type="text/css" href="student.css">

</head>
<body>
	<?php include 'header.php'; ?>
	
	
<div  style="margin-left: 150PX;width: 1029px; height: 40px;background-color: rgb(0,112,223);font-size: 30px; text-align: center;margin-top: 50px;
">  <B>TPO'S MESSAGE</B>	</div>
<div id="cntnt" style="margin-left: 410px; margin-top: 10px; width: 600px; height: auto;text-align: justify;  font-size: 20px;">
<center> <img src="tpo_knit.jpg" /><p><b>Prof. S.K.Sinha </b></p></center>Kamla Nehru Institute of Technology is a government college affiliated to the Dr. A. P. J. Abdul Kalam University (formerly UPTU). It has a very good reputation all over the nation and the alumni of KNIT are spread all over the globe. KNIT is one of the premier state govt. engineering Institute preferred for recruitment to many reputed organizations and companies because of the kind of potential and intellect that the students of this institute have been displaying over the years.
</div>
</body>
</html><?php include 'footer.php'; ?>
