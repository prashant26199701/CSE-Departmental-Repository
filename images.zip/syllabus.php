<?php include 'header.php'; ?>


<!DOCTYPE html>


<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="student.css">
</head>
<body>


	
	<div class="div1" style="margin-left: 146PX;margin-top: 20px;">  <B>SYLLABUS</B>	</div>
	<div style="margin-left: 210px;margin-top: 10px;font-size: 20px;">
	<table><li><a href="http://knit.ac.in/pdf/btech_1st_year_starting_session_16sap13.pdf" target="_blank">B.Tech  First Year (Common to All Branches)  Starting Session 2013-14</a></li>
<li><a href="http://knit.ac.in/pdf/cs_280217.pdf" target="_blank">B.Tech in Computer Science & Engineering</a></li>
<li><a href="http://knit.ac.in/pdf/it_280217.pdf" target="_blank">B.Tech in Information Technology</a></li>
 <li><a href="http://knit.ac.in/pdf/Full-time-mtech_211217.pdf" target="_blank">M.Tech Full Time (Comp. Sc.)</a></li>
            <li><a href="http://knit.ac.in/pdf/Full-time-mtech_211217.pdf" target="_blank">M.Tech Part Time (Comp. Sc.)</a></li>
			  
			 <li><a href="http://knit.ac.in/pdf/MTechCSFT.pdf" target="_blank">M.Tech Comp. Sc. Full Time(Effective from 2017)</a></li>
			 <li><a href="http://knit.ac.in/pdf/MTechCSPT.pdf" target="_blank">M.Tech Comp. Sc. Part Time(Effective from 2017)</a></li>
            <li><a href="http://knit.ac.in/pdf/mca_280217.pdf" target="_blank">MCA (Master of computer Applications)</a></li>
			  <li><a href="http://knit.ac.in/pdf/MCA-2017-18.pdf" target="_blank">MCA (Effective from 2017)</a></li>  </table></div>
	
</body>
</html>
<?php include 'footer.php'; ?>