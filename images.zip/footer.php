<!DOCTYPE html>
<html>
<head>
	<title></title>
	
		<link rel="stylesheet" href="https://unpkg.com/@coreui/icons@1.0.0/css/all.min.css">
<link rel="stylesheet" href="https://unpkg.com/@coreui/icons@1.0.0/css/free.min.css">
<link rel="stylesheet" href="https://unpkg.com/@coreui/icons@1.0.0/css/brand.min.css">
<link rel="stylesheet" href="https://unpkg.com/@coreui/icons@1.0.0/css/flag.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">




	
</head>
<body>
	<b><div  style="height: 50px; width: 1029px; margin-top: 10px; text-align: center;margin-left: 150px;background-color: rgb(0,112,223); padding-top: 10px;font-family: Arial;">
		<i class="cib-googles-cholar"></i>
<?php 
echo "Copyright &copy; 1999-" . date("Y") . " KNIT,SULTANPUR";
?>
</b><i class="fa fa-caret-down"></i>
<i class="cil-envelope-closed"></i>

</div>
</body>
</html>