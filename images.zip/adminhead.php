



<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</style>


	<link rel="stylesheet" type="text/css" href="index.css"> 
</head>
<body>
	<header><div>

<div class="logo"> 
	<div class="leftfloat">
		<div class="cse" text="white"><font class="font1" color="white">COMPUTER SCIENCE & ENGINEERING </font><br> <font class="h4" color="white">KNIT SULTANPUR</font></div>
		<div class="vl"></div>
	<div   class="leftfloat1"></div>
</div><hr>


	

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
	margin-top: 14px;
  overflow: hidden;
  background-color: rgb(0,112,223); 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: rgb(0,112,180);
}

.subnav-content {
  display: none;
  position: absolute;
  
  left: 150px;
  background-color: rgb(0,112,180);
  width: 1029px;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color:rgb(0,112,223);
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}




.subnav-content-1 {
  display: none;
  position: absolute;
  
  right: 30px;
  background-color: rgb(0,112,180);
  width: 1029px;
  z-index: 2;
}

.subnav-content-1 a {
  float: left;
  color: white;
 
  text-decoration: none;
}

.subnav-content-1 a:hover {
  background-color:rgb(0,112,223);
  color: red;
   right:100px;
   
}

.subnav-content:hover .subnav-content-1 {
  display: block;
}




</style>
</head>
<body>
<div class="navbar" style="margin-left: 350px;">
  <a href="index.php">Home</a>
  <a href="Director.php">Director's Desk</a> 
 
  <div >
  
  <a href="adminlogin.php">Admin Login</a>
</div>

<div style="padding:0 16px">
 </div>



</div></header>


















</body>
</html>



 