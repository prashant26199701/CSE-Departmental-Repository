
 
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>

<body>
	<?php
 
    include("config.php");
 
    if(isset($_POST['but_upload'])){
        $name = $_FILES['file']['name'];

$Email=$_POST["but_upload3"];
$username=$_POST["but_upload5"];
$branch=$_POST["but_upload2"];
$post=$_POST["but_upload1"];
$address=$_POST["but_upload7"];
        $target_dir = "upload/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);

        // Select file type
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Valid file extensions
        $extensions_arr = array("jpg","jpeg","png","gif");

        // Check extension
        if( in_array($imageFileType,$extensions_arr) ){
            
            // Convert to base64 
            $image_base64 = base64_encode(file_get_contents($_FILES['file']['tmp_name']) );
            $image = 'data:image/'.$imageFileType.';base64,'.$image_base64;

            // Insert record

            $query = "insert into images(name,image,Email,username,branch,post,address) values('".$name."','".$image."','".$Email."','".$username."','".$branch."','".$post."','".$address."')";

           
            mysqli_query($con,$query) or die(mysqli_error($con));
            
            // Upload file
            move_uploaded_file($_FILES['file']['tmp_name'],'upload/'.$name);
            



        }

    
    }
    if(isset($_POST['but_upload'])){
    header('location:updataimg.php');
    exit();
   }
   ?>

	
   

    <form method="post" action="" enctype='multipart/form-data'   id="myform">

        <input type='file' name='file' /><br>
        name
        <input type='text'  name='but_upload6'><br>
        post <input type='text'  name='but_upload1'><br>
          branch<input type='text'  name='but_upload2'><br>
           email<input type='email'  name='but_upload3'><br>
           
       usernsme <input type='text'  name='but_upload5'><br>
       address <input type='text' value='Save name' name='but_upload7'>
       <input type='submit'   name='but_upload'>
    </form>
    
    
    

</body>

</html>