<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php include 'header.php'; ?>


		<div  style="margin-left: 150PX;width: 1029px; height: 40px;background-color: rgb(0,112,223);font-size: 30px; text-align: center;margin-top: 50px;
">  <B>Hod's Desk</B>	</div>
<div id="cntnt" style="margin-left: 410px; margin-top: 10px; width: 600px; height: auto;text-align: justify;  font-size: 20px;">
		 <center> <img src="direor.jpg" /><p><b>Prof(Dr.) Neelendra Badal </b></p></center><p>Kamla Nehru Institute  of Technology, Sultanpur has marked its presence as one of the leading  technical institutes for providing congenial environment for the holistic  growth of the students for the last four decades by and large. Strength and standing  of the institute is witnessed by the professionally competent alumni proving  their worth in academia and industry all over the country and overseas. In  order to contribute to the socio-economic growth of the region in and around  Sultanpur district, the institute renders testing and consultancy services to  neighbouring industries, and of course to government &amp; other agencies.</p><br>
<p>The institute looks  forward to becoming as one of the most preferred destination for young students aspiring to  emerge as successful engineers, technologists and good human beings. We need to  work even harder to maintain excellence in teaching &amp; research and to  achieve pioneer position in the area of technical education. I strongly believe  that the key to success of an institute is the dedicated efforts of its each  and every individual. I am sure and confident that with the help, support and  commitment of our highly qualified and experienced faculty members, supportive  administration, dedicated staff members, and highly motivated &amp;  enthusiastic students, we shall be able to carve the niche in pursuit of our  vision and add to the professional development of the state and country.</p> </div>
        
		<!-- InstanceEndEditable --></div>
</div>
<div>


</body>
</html>
<?php include 'footer.php'; ?>