<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	
	<center><div style="height: 200px; width: 300px;  box-shadow: 3px 3px 3px 3px grey; font-size: 15px;margin-top: 50px;">
		<h1>!Login successfully!</h1>
		<a href="studentadd.php" style="font-size: 20px">Add Student's Details</a><br><br>
		<a href="upload.php" style="font-size: 20px;">Add Faculty Details</a>
	</div></center>
	

</body>
</html>
<?php include 'footer.php'; ?>