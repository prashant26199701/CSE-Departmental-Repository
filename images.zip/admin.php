<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title></title>
	<link rel="stylesheet" type="text/css" href="student.css">
</head>
<body class="blur">
  <?php include 'header.php'; ?>


	 
<div  style="margin-left: 150PX;width: 1029px; height: 40px;background-color: rgb(0,112,223);font-size: 30px; text-align: center;margin-top: 50px;
">  <B>ADMINISTRATION</B> 
<div style="float: right;" color: black;><a href="login.php" >Admin Login</a></div></div>

	  <div style="width: 900px; margin-left: 210px; font-size: 20px; height: auto; text-align: justify;margin-top: 10px;
	  " > The Institute is an Autonomous Statutory Organization registered under Societies
          Registration Act of Uttar Pradesh. It is fully financially and administratively controlled by the
          U.P. Government. The affairs of the Institute are centrally managed by the Board of
          Governors (BOG) with Hon’ble Minister of Technical Education, U.P. as the Chairman.
          There are different Committees such as Finance Committee, Administrative Committee, Academic Committee, Purchase
          Committee, and Building & Works Committee etc to assist the BOG in administering the
          the Institute. The academic matters of Students are governed by A.K.T.U,
		  Lucknow. Director is Head of the Institute who is assisted by Professors
          and officers in various capacities in running the affairs of the Institute. </div><br>
          <br>
          <h3></h3>
          <div style="width: 1029px; margin-left: 146px; height: auto; border: none; font-size: 20px;" >
          <table width="900px" border="solid" align="center" >
           
          <!--  <tr>
              <td align="center" valign="top"><img src="images/bulit.jpg" alt="" width="17" height="18"></td>
              <td valign="top" style="width:440px;">
              <a href="pdf/bylaws_mar0216.pdf" target="_blank"><font color="#000000">By-laws</font></a></td>
              <td valign="top">&nbsp;</td>
            </tr>-->
			
           
            <tr>
              
              <td width="435" ><p align="center">Chairman Board of Governors</td>
              <td width="210" valign="top"><p align="center">Er. V.K. Mishra </td>
            </tr>
            <tr>
             
              <td width="435"><p align="center">Vice Chairman Board of Governors</td>
              <td width="210"><p align="center">Shri Bhuvnesh Kumar, IAS ,<br> Secretary, Technical  Education </td>
            </tr>
            <tr>
             
              <td width="435"><p align="center"><!--a href="pdf/director_12032014.pdf" target="_blank">Director</a-->Director</td>
              <td width="210"><p align="center">Prof. J.P. Pandey </td>
            </tr>
			    <tr>
             
              <td width="435"><p align="center">Registrar&nbsp;</td>
              <td width="210"><p align="center">Sri B.P. Chaurasia</td>
            </tr>
            <tr>
             
              <td width="435"><p align="center">Dy. Registrar&nbsp;</td>
              <td width="210"><p align="center"><!--Shri S.C. Bhatt -->Shri C. M Shukla</td>
            </tr>
            <tr>
             
              <td><p align="center">Finance &amp;&nbsp;Accounts    Officer&nbsp;</td>
              <td><p align="center">Shri C. M Shukla</td>
            </tr>
            <tr>
             
              <td><p align="center">Assistant Registrar&nbsp;</td>
              <td><p align="center">Shri S. K. Srivastava</td>
            </tr>
            <tr>
             
              <td><a href="http://knit.ac.in/pdf/AC2017.pdf" target="_blank"><font color="#000000"><p align="center">Members of Academic Council and Faculty Board</font></a> </td>
              <td></td>
            </tr>
          
          
            <!--<tr>
              <td align="center" valign="top"><img src="images/bulit.jpg" alt="" width="17" height="18"></td>
              <td>Assistant Registrar&nbsp;(Accounts)</td>
              <td>Shri S. Srivastava</td>
            </tr>-->

             <tr>
             
              <td valign="top" style="width:440px;"><a href="http://knit.ac.in/pdf/beares_060719.pdf" target="_blank"><font color="#000000"><p align="center">List of Office-Bearers</font></a></td>
              <td valign="top">&nbsp;</td>
            </tr>
          </table>
    
          <br>
          <br>
        
        </div>
        <!-- InstanceEndEditable --></div>










</body>
</html>