 
<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="student.css">
</head>
<body>

	<div class="div1" style="margin-top: 10PX;margin-left: 146PX;">  <B>WORKSHOP</B>	</div>

<div id="cntnt" style="margin-left: 210px; margin-top: 10px; width: 900px; height: auto;text-align: justify;  font-size: 20px;">
	

			
<p>Technical Education plays a pivotal role in  development of the country by creating skilled manpower, enhancing industrial  productivity and improving the quality of its people.<br><br>
  Hence, the impulse pf imparting technical  training to the novice students paves the way for this exigent development and  training and workshop are held to make them industry ready.<br><br>
  As per the norms of AICTE, Institute provides  various training and workshop sessions for the students which keeps them on  their toes, right since their sophomore year. Catering to the need of present  scenario, institute provides the desired certified courses on up-to-the minute  technical topics.</p><br>
<strong><u>Trainings conducted for the  session 2016-17:</u></strong>
<table class="boder" width="100%" cellspacing="1" cellpadding="2" border="0" align="center">
  <tr>
    <th width="29%">Branch</th>
    <th width="12%">Year</th>
    <th width="59%">Topic Name</th>
  </tr>
  
   
  <tr>
    <td>Computer Sc. Engg.</td>
    <td>2nd </td>
    <td>LINUX</td>
  </tr>
  <tr>
    <td>Computer Sc. Engg.</td>
    <td>3rd </td>
    <td>Data    Analysis</td>
  </tr>
  
  <tr>
    <td>Information Tech.</td>
    <td>2nd </td>
    <td>Networking</td>
  </tr>
  <tr>
    <td>Information Tech.</td>
    <td>3rd  </td>
    <td>Networking</td>
  </tr>
  <tr>
    <td>MCA</td>
    <td>2nd </td>
    <td>ASP.NET</td>
  </tr>
</table><br>
 <strong><u>Trainings to be conducted for the  session 2017-18:</u></strong>
<table class="boder" width="100%" cellspacing="1" cellpadding="2" border="0" align="center">
  <tr>
    <th width="29%">Branch</th>
    <th width="12%">Year</th>
    <th width="59%">Topic Name</th>
  </tr>
  
  <tr>
    <td>Computer Sc. Engg.</td>
    <td>2nd </td>
    <td>Android App Development</td>
  </tr>
  <tr>
    <td>Computer Sc. Engg.</td>
    <td>3rd </td>
    <td>Machine Learning</td>
  </tr>
 
  <tr>
    <td>Information Tech.</td>
    <td>2nd </td>
    <td>Networking with LINUX Security</td>
  </tr>
  <tr>
    <td>Information Tech.</td>
    <td>3rd   </td>
    <td>Cloud Computing</td>
  </tr>
</table>
</div>

</body>
</html>
<?php include 'footer.php'; ?>