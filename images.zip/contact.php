
<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" type="text/css" href="student.css">
</head>
<body>
 <div  style="margin-left: 150PX;width: 1029px; height: 40px;background-color: rgb(0,112,223);font-size: 30px; text-align: center;margin-top: 10px;
">  <B>CONTACTS</B>  </div>
<div id="cntnt" style="width: 1029px; margin-left: 150px;margin-top: 20px; ">
<table id="abhi" cellpadding="2" cellspacing="2" width="100%">
<tbody>
<tr>
<td id="phone" colspan="4" align="left" valign="center">Phones/Mobiles</td></tr>
<tr>
<td id="std" colspan="4" align="left" bgcolor="#f5f5f5" valign="center">City-STD Code : 05362 </td></tr>
<tr>
<td id="designation" align="left" valign="center" width="40%"><strong>Designation</strong></td>
<td id="designation" align="left" valign="center" width="15%"><strong>Name</strong> </td>
<td id="designation" align="left" valign="center" width="15%"><strong>Mobile No.</strong> </td>
<td id="designation" align="left" valign="center" width="30%"><strong>E-Mail</strong> </td></tr>
 
  <tr>
    <td><p>Director</p></td>
    <td><p>Prof.J.P.Pandey</p></td>
    <td><p>9415041790</p></td>
    <td><p>director@knit.ac.in</p></td>
  </tr>
 <!-- <tr>
    <td><p>Registrar</p></td>
    <td><p>241238</p></td>
    <td><p>7905218128</p></td>
    <td><p>-</p></td>
  </tr>-->
   <tr>
    <td><p>Registrar</p></td>
    <td><p>Prof.B.P.Chaurasia</p></td>
    <td><p>9415068565</p></td>
    <td><p><a href="mailto:bp_chaurasia@knit.ac.in">bp_chaurasia@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Finance    &amp; Accounts Officer</p></td>
    <td><p>Sri C.M.Shukla</p></td>
    <td><p>9838175649</p></td>
    <td><p><a href="mailto:charanmshukla@yahoo.com">charanmshukla@yahoo.com</a></p></td>
  </tr>
  <tr>
    <td><p>Dean of Academic Affair</p></td>
    <td><p>Prof.M.K.Gupta</p></td>
    <td><p>9415056859</p></td>
    <td><p><a href="mailto:mkgupta@knit.ac.in">mkgupta@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Dean of    Student welfare</p></td>
    <td><p>Prof.Y.K.Mishra</p></td>
    <td><p>9415136833</p></td>
    <td><p><a href="mailto:ykmishra@knit.ac.in">ykmishra@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>DeanR&amp;D</p></td>
    <td><p>Prof.A.S.Pandey</p></td>
    <td><p>9415091697</p></td>
    <td><p><a href="mailto:aspandey@knit.ac.in">aspandey@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Chairman CSA</p></td>
    <td><p>Prof.A.S.Pandey</p></td>
    <td><p>9415091697</p></td>
    <td><p><a href="mailto:aspandey@knit.ac.in">aspandey@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>In-charge Security</p></td>
    <td><p>Prof.B.P.Chaurasia</p></td>
    <td><p>9415068565</p></td>
    <td><p><a href="mailto:bp_chaurasia@knit.ac.in">bp_chaurasia@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Prof. In-charge, T&amp;P</p></td>
    <td><p>Prof.S.K.Sinha</p></td>
    <td><p>9415091562</p></td>
    <td><p><a href="mailto:sksinha@knit.ac.in">sksinha@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Prof.In-charge, Library</p></td>
    <td><p>Prof.D.L.Gupta</p></td>
    <td><p>9415156184</p></td>
    <td><p><a href="mailto:dlgupta@knit.ac.in">dlgupta@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Medical officer</p></td>
    <td><p>&nbsp;</p></td>
    <td><p>9415046464</p></td>
    <td><p><a href="mailto:srimaasul@gmail.com">srimaasul@gmail.com</a></p></td>
  </tr>
  <tr>
    <td><p>Head Applied Sc. &amp; Humanities</p></td>
    <td><p>Prof.R.P.Tripathi</p></td>
    <td><p>9837239545</p></td>
    <td><p><a href="mailto:"></a></p></td>
  </tr>
  <tr>
    <td><p>Head of    Civil Engg. Dept.</p></td>
    <td><p>Prof.U.K.Maheshwari</p></td>
    <td><p>9450069760</p></td>
    <td><p><a href="mailto:umaheshwari@hotmail.com">umaheshwari@hotmail.com</a></p></td>
  </tr>
  <tr>
    <td><p>Head of    Comp. Sc. &amp; Engg. Dept.</p></td>
    <td><p>Prof.N.Badal</p></td>
    <td><p>9415077454</p></td>
    <td><p><a href="mailto:nbadal@knit.ac.in">n_badal@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Head of    Electrical Engg. Dept</p></td>
    <td><p>Pro.R.P.Payasi</p></td>
    <td><p>9839835741</p></td>
    <td><p><a href="mailto:payasirp@knit.ac.in"></a>payasirp@knit.ac.in</p></td>
  </tr>
  <tr>
    <td><p>Head of    Mechanical Engg. Dept.</p></td>
    <td><p>Prof.J.P.Pandey</p></td>
    <td><p>9415041790</p></td>
    <td><p><a href="mailto:director@knit.ac.in">director@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Head of Elecronics Engg. Dept.</p></td>
    <td><p>Pro.A.K.Singh</p></td>
    <td><p>9651605690</p></td>
    <td><p><a href="mailto:aksingh1@knit.ac.in">aksingh1@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Chief Warden <br>
      (Boys    Hostel)</p></td>
    <td><p>Prof.Samir Srivastava</p></td>
    <td><p>9415077351</p></td>
    <td><p><a href="mailto:samir@knit.ac.in">samir@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Chief Warden <br>
      (Girls    Hostel)</p></td>
    <td><p>Prof.Alka Singh</p></td>
    <td><p>9838513811</p></td>
    <td><p><a href="mailto:alkasingh@knit.ac.in">alkasingh@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden  Aryabhatta</p></td>
    <td><p>Pro.A.K.Agrawal</p></td>
    <td><p>9415179810</p></td>
    <td><p><a href="mailto:abhaykumaragrawal@knit.ac.in">abhaykumaragrawal@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden Gargi Hostel</p></td>
    <td><p>Prof. Ruchin Agrawal</p></td>
    <td><p>9453238876</p></td>
    <td><p><a href="mailto:ruchin@knit.ac.in">ruchin@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden    Maitreyee Hostel</p></td>
    <td><p>Prof.S.P.Gangwar</p></td>
    <td><p>8765890822</p></td>
    <td><p><a href="mailto:sompalgangwar@knit.ac.in">sompalgangwar@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden    Khosla Hostel</p></td>
    <td><p>Prof.Rajnish Singh</p></td>
    <td><p>9554599711</p></td>
    <td><p><a href="mailto:rajnish.singh@knit.ac.in">rajnish.singh@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden VS    Hostel</p></td>
    <td><p>Prof.Amit Medhavi</p></td>
    <td><p>9532888592</p></td>
    <td><p><a href="mailto:amitmedhavi@knit.ac.in">amitmedhavi@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden New    Hostel</p></td>
    <td><p>Prof. Samir<br>Srivastava</p></td>
    <td><p>9415077351</p></td>
    <td><p><a href="mailto:samir@knit.ac.in">samir@knit.ac.in</a></p></td>
  </tr>
  
    <tr>
    <td><p>Warden M. N. Shah Hostel</p></td>
    <td><p>Prof. A.K.Agrawal</p></td>
    <td><p>9415179810</p></td>
    <td><p><a href="mailto:abhaykumaragrawal@knit.ac.in">abhaykumaragrawal@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden Vikram Sarabhai  Hostel</p></td>
    <td><p>Prof. A.K. Chauhan</p></td>
    <td><p>9307448592</p></td>
    <td><p><a href="mailto:akhileshkumarchauhan@knit.in">akhileshkumarchauhan@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden Raman Hostel</p></td>
    <td><p>Prof.Shashank <br>Kumar</p></td>
    <td><p>9453280888</p></td>
    <td><p><a href="mailto:	Shashank.kumar@knit.ac.in">Shashank.kumar@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Warden Kalam Hostel</p></td>
    <td><p>Prof.Shashank<br> Kumar</p></td>
    <td><p>9453280888</p></td>
    <td><p><a href="mailto:Shashank.kumar@knit.ac.in">Shashank.kumar@knit.ac.in</a></p></td>
  </tr>
  <tr>
    <td><p>Security    Office<br>
      (Main Gate)</p></td>
    <td><p>225291</p></td>
    <td><p>&nbsp;</p></td>
    <td><p>&nbsp;</p></td>
  </tr>
</tbody></table></div><!-- InstanceEndEditable --></div></div>
<div>
</body>
</html>
<?php include 'footer.php'; ?>