<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="student.css">
</head>
<body>
	

		<div id="wlcmmn">
			<div id="wlcm1"></div>
			<div class="div1" style="margin-left: 146px;margin-top: 20px;"><!-- InstanceBeginEditable name="welcomearea" -->Internship <!-- InstanceEndEditable --></div>
			<div id="wlcm3"></div>
		</div>
		<!-- InstanceBeginEditable name="contentarea" -->
		<div id="cntnt" style="margin-left: 210px; margin-top: 10px; width: 900px; height: auto;text-align: justify;  font-size: 20px;">

<p >
  Taking forward the zeal of  trainings, internships are provided by the institute to techno birds, to expose  them to the working of the corporate worlds and cutting-edge competition as  well as work pressure which prevails there.<br>
  The institute provides  internships to the students, to provide them exposure to the trending world and  current working scenario of the modern corporate<br>
  Students works as Remote as well  as direct interns under professional mentors to work under the professional  environment on various projects.<br>
  Many companies provide  internship to our college students, some of these are:</p></div><div style="margin-left: 210px; margin-top: 0px;text-align: justify;width: 900px; font-size: 20px; box-shadow: 3px 3px 3px 3px gray;height: auto;>

<ul class="UL1">
<li>ITTIAM Systems</li>
<li>Adobe</li>
<li>TCS</li>
<li>AnsalAPI</li>
<li>L&amp;T</li>
<li>Pie INFOCOMM</li>
<li>Nirvana Solutions</li>
<li>Atventus</li>
<li>Cedcos0073</li>
<li>Newgen Apps and many more…</li>

		</div>
		<!-- InstanceEndEditable --></div>
</div>
<div>
</body>
</html>
<?php include 'footer.php'; ?>